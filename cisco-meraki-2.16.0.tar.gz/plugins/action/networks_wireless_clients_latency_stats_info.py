#!/usr/bin/env python
# -*- coding: utf-8 -*-

# Copyright (c) 2021, Cisco Systems
# GNU General Public License v3.0+ (see LICENSE or https://www.gnu.org/licenses/gpl-3.0.txt)

from __future__ import (absolute_import, division, print_function)
__metaclass__ = type
from ansible.plugins.action import ActionBase
try:
    from ansible_collections.ansible.utils.plugins.module_utils.common.argspec_validate import (
        AnsibleArgSpecValidator,
    )
except ImportError:
    ANSIBLE_UTILS_IS_INSTALLED = False
else:
    ANSIBLE_UTILS_IS_INSTALLED = True
from ansible.errors import AnsibleActionFail
from ansible_collections.cisco.meraki.plugins.plugin_utils.meraki import (
    MERAKI,
    meraki_argument_spec,
)

# Get common arguments specification
argument_spec = meraki_argument_spec()
# Add arguments specific for this module
argument_spec.update(dict(
    networkId=dict(type="str"),
    clientId=dict(type="str"),
    t0=dict(type="str"),
    t1=dict(type="str"),
    timespan=dict(type="float"),
    band=dict(type="str"),
    ssid=dict(type="int"),
    vlan=dict(type="int"),
    apTag=dict(type="str"),
    fields=dict(type="str"),
))

required_if = []
required_one_of = []
mutually_exclusive = []
required_together = []


class ActionModule(ActionBase):
    def __init__(self, *args, **kwargs):
        if not ANSIBLE_UTILS_IS_INSTALLED:
            raise AnsibleActionFail(
                "ansible.utils is not installed. Execute 'ansible-galaxy collection install ansible.utils'")
        super(ActionModule, self).__init__(*args, **kwargs)
        self._supports_async = False
        self._supports_check_mode = True
        self._result = None

    # Checks the supplied parameters against the argument spec for this module
    def _check_argspec(self):
        aav = AnsibleArgSpecValidator(
            data=self._task.args,
            schema=dict(argument_spec=argument_spec),
            schema_format="argspec",
            schema_conditionals=dict(
                required_if=required_if,
                required_one_of=required_one_of,
                mutually_exclusive=mutually_exclusive,
                required_together=required_together,
            ),
            name=self._task.action,
        )
        valid, errors, self._task.args = aav.validate()
        if not valid:
            raise AnsibleActionFail(errors)

    def get_all(self, params):
        new_object = {}
        if params.get("networkId") is not None:
            new_object["networkId"] = params.get(
                "networkId")
        if params.get("clientId") is not None:
            new_object["clientId"] = params.get(
                "clientId")
        if params.get("t0") is not None:
            new_object["t0"] = params.get(
                "t0")
        if params.get("t1") is not None:
            new_object["t1"] = params.get(
                "t1")
        if params.get("timespan") is not None:
            new_object["timespan"] = params.get(
                "timespan")
        if params.get("band") is not None:
            new_object["band"] = params.get(
                "band")
        if params.get("ssid") is not None:
            new_object["ssid"] = params.get(
                "ssid")
        if params.get("vlan") is not None:
            new_object["vlan"] = params.get(
                "vlan")
        if params.get("apTag") is not None:
            new_object["apTag"] = params.get(
                "apTag")
        if params.get("fields") is not None:
            new_object["fields"] = params.get(
                "fields")

        return new_object

    def run(self, tmp=None, task_vars=None):
        self._task.diff = False
        self._result = super(ActionModule, self).run(tmp, task_vars)
        self._result["changed"] = False
        self._check_argspec()

        self._result.update(dict(meraki_response={}))

        meraki = MERAKI(params=self._task.args)

        response = meraki.exec_meraki(
            family="wireless",
            function='getNetworkWirelessClientLatencyStats',
            params=self.get_all(self._task.args),
        )
        self._result.update(dict(meraki_response=response))
        self._result.update(meraki.exit_json())
        return self._result
